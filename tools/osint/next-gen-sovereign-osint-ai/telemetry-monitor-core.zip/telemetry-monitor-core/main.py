# Entry point for telemetry-monitor-core

if __name__ == "__main__":
    print("Launching telemetry-monitor-core")
