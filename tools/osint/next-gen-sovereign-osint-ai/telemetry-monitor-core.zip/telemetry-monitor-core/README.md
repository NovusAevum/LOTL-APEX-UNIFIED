# Telemetry Monitor Core

Logging, monitoring, Grafana/Prometheus pipelines, ELK integration
