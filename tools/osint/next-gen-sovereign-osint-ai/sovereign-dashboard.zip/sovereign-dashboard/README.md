# Sovereign Dashboard

Electron + Vercel unified UI interface (main GUI frontend)
