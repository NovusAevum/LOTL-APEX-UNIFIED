# Entry point for sovereign-dashboard

if __name__ == "__main__":
    print("Launching sovereign-dashboard")
