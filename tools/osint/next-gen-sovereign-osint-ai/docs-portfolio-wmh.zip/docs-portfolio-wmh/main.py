# Entry point for docs-portfolio-wmh

if __name__ == "__main__":
    print("Launching docs-portfolio-wmh")
