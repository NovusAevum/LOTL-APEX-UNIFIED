# Entry point for automation-playbooks

if __name__ == "__main__":
    print("Launching automation-playbooks")
