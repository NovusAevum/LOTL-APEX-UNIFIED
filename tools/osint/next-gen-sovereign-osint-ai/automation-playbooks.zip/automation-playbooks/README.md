# Automation Playbooks

CI/CD scripts, cron jobs, data sync, alerting, task runners
