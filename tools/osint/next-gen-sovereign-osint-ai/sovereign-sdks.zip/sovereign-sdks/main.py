# Entry point for sovereign-sdks

if __name__ == "__main__":
    print("Launching sovereign-sdks")
