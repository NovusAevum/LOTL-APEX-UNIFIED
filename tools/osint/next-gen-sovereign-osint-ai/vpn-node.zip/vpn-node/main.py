# Entry point for vpn-node

if __name__ == "__main__":
    print("Launching vpn-node")
