# Entry point for sovereign-api-gateway

if __name__ == "__main__":
    print("Launching sovereign-api-gateway")
