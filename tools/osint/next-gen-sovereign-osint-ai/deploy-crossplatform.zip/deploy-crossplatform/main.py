# Entry point for deploy-crossplatform

if __name__ == "__main__":
    print("Launching deploy-crossplatform")
