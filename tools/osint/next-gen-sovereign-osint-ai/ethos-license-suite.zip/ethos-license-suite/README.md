# Ethos License Suite

Custom Islamic-Malay ethical license and derivations
