# Entry point for ethos-license-suite

if __name__ == "__main__":
    print("Launching ethos-license-suite")
