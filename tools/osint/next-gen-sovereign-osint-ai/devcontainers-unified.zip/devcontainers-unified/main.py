# Entry point for devcontainers-unified

if __name__ == "__main__":
    print("Launching devcontainers-unified")
