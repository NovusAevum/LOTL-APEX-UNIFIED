# Entry point for osint-agent-suite

if __name__ == "__main__":
    print("Launching osint-agent-suite")
